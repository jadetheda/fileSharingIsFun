const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/actors/TimelineDatasource.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  '      && !(filter.hidePostsFromBots && isBotAuthored)\n      && !(filter.hideSeenPostsEnabled && filter.hideReadPosts && isSeen)',
  '      && !(filter.hidePostsFromBots && isBotAuthored)'
);

fs.writeFileSync(path, content);
console.log('done');
