const fs = require('fs');
const path = 'ios-workspace/Packages/StatusKit/Sources/StatusKit/Row/Subviews/StatusRowMediaPreviewView.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  'let url: URL\n  let previewUrl: URL?',
  'let url: URL\n  let fallbackUrl: URL?\n  let previewUrl: URL?'
);

content = content.replace(
  'id = attachment.id\n    self.url = url\n    previewUrl =',
  'id = attachment.id\n    self.url = url\n    fallbackUrl = attachment.url\n    previewUrl ='
);

content = content.replace(
  'MediaUIAttachmentVideoView(viewModel: .init(url: displayData.url))',
  'MediaUIAttachmentVideoView(viewModel: .init(url: displayData.url, fallbackUrl: displayData.fallbackUrl))'
);

fs.writeFileSync(path, content);
console.log('done');
