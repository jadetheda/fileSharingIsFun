#!/bin/sh

echo "================================================="
echo "   iOS Development Workspace Setup (a-shell)     "
echo "================================================="
echo ""
echo "This script will configure git and clone your repository"
echo "using a GitHub Personal Access Token (PAT)."
echo ""

GIT_NAME="anna"
GIT_EMAIL="jmcelhoes@gmail.com"

git config --global user.name "$GIT_NAME"
git config --global user.email "$GIT_EMAIL"
git config --global credential.helper store
echo "Git identity configured for $GIT_NAME ($GIT_EMAIL)."
echo ""

GH_USER="jadetheda"
GH_PAT="${GITHUB_PAT}"
GH_REPO="IceCubesApp"

if [ -z "$GH_PAT" ]; then
  echo "Error: GITHUB_PAT environment variable is not set."
  echo "Please set it before running this script."
  exit 1
fi

echo ""
echo "Cloning repository..."
git clone "https://${GH_USER}:${GH_PAT}@github.com/${GH_USER}/${GH_REPO}.git"
echo ""
echo "Setup complete! You can now copy your extracted workspace files into ${GH_REPO}/ and push updates."
