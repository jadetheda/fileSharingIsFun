#!/bin/sh

echo "================================================="
echo "   iOS Development Workspace Setup (a-shell)     "
echo "================================================="
echo ""
echo "This script will configure git and clone your repository"
echo "using a GitHub Personal Access Token (PAT)."
echo ""

GIT_NAME="anna"
GIT_EMAIL="jmcelhoes@gmail.com"

git config --global user.name "$GIT_NAME"
git config --global user.email "$GIT_EMAIL"
git config --global credential.helper store

echo "Git identity configured for $GIT_NAME ($GIT_EMAIL)."
echo ""

GH_USER="jadetheda"
GH_PAT="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"
GH_REPO="IceCubesApp"

echo ""
echo "Cloning repository..."
git clone "https://${GH_USER}:${GH_PAT}@github.com/${GH_USER}/${GH_REPO}.git"

echo ""
echo "Setup complete! You can now copy your extracted workspace files into ${GH_REPO}/ and push updates."
