
const fs = require("fs");
const path = "ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineListView.swift";
let content = fs.readFileSync(path, "utf8");

// We need to completely rewrite the body
const bodyRegex = /  var body: some View \{[\s\S]*?^  \}$/m;
const match = content.match(bodyRegex);
