const fs = require("fs");
const path = "./server.ts";
let content = fs.readFileSync(path, "utf8");

content = content.replace(/const escapedMessage = commitMessage.replace\(\/\x22\/g, '\\\\\\\\"\([^]+?\)execSync\(`git commit -m "\$\{escapedMessage\}"`, \{ cwd: workspacePath, stdio: 'pipe' \}\);/, "const { execFileSync } = require('child_process');\n        execFileSync('git', ['commit', '-m', commitMessage], { cwd: workspacePath, stdio: 'pipe' });");

fs.writeFileSync(path, content);
