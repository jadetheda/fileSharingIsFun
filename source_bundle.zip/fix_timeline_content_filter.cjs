const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/TimelineContentFilter.swift';
let content = fs.readFileSync(path, 'utf8');

// Replace standard variables with Observation-compatible ones

function replaceProp(name, storageName) {
  const oldStr = `  public var ${name}: Bool {\n    didSet {\n      storage.${storageName || name} = ${name}\n    }\n  }`;
  const newStr = `  @ObservationIgnored\n  private var _${name}: Bool = false\n  public var ${name}: Bool {\n    get {\n      access(keyPath: \\.${name})\n      return _${name}\n    }\n    set {\n      withMutation(keyPath: \\.${name}) {\n        _${name} = newValue\n        storage.${storageName || name} = newValue\n      }\n    }\n  }`;
  content = content.replace(oldStr, newStr);
}

replaceProp('showBoosts');
replaceProp('showReplies');
replaceProp('showThreads');
replaceProp('showQuotePosts');
replaceProp('hidePostsWithMedia');
replaceProp('hidePostsWithoutMedia');
replaceProp('hidePostsFromBots');
replaceProp('hideStatusText');
replaceProp('isGalleryMode');
replaceProp('hideReadPosts');

// Update initializer to set the backing variables
content = content.replace(
  '    showBoosts = storage.showBoosts',
  '    _showBoosts = storage.showBoosts'
);
content = content.replace(
  '    showReplies = storage.showReplies',
  '    _showReplies = storage.showReplies'
);
content = content.replace(
  '    showThreads = storage.showThreads',
  '    _showThreads = storage.showThreads'
);
content = content.replace(
  '    showQuotePosts = storage.showQuotePosts',
  '    _showQuotePosts = storage.showQuotePosts'
);
content = content.replace(
  '    hidePostsWithMedia = storage.hidePostsWithMedia',
  '    _hidePostsWithMedia = storage.hidePostsWithMedia'
);
content = content.replace(
  '    hidePostsWithoutMedia = storage.hidePostsWithoutMedia',
  '    _hidePostsWithoutMedia = storage.hidePostsWithoutMedia'
);
content = content.replace(
  '    hidePostsFromBots = storage.hidePostsFromBots',
  '    _hidePostsFromBots = storage.hidePostsFromBots'
);
content = content.replace(
  '    hideStatusText = storage.hideStatusText',
  '    _hideStatusText = storage.hideStatusText'
);
content = content.replace(
  '    isGalleryMode = storage.isGalleryMode',
  '    _isGalleryMode = storage.isGalleryMode'
);
content = content.replace(
  '    hideReadPosts = storage.hideReadPosts',
  '    _hideReadPosts = storage.hideReadPosts'
);

fs.writeFileSync(path, content);
console.log('done');
