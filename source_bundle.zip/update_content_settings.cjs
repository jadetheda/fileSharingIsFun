const fs = require('fs');
const path = 'ios-workspace/IceCubesApp/App/Tabs/Settings/ContentSettingsView.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  '        Toggle(isOn: $userPreferences.remoteMediaAutoFallback) {\n          Text("Auto fallback to remote media (10s)")\n        }\n        Toggle(isOn: $userPreferences.remoteMediaAlwaysForce) {\n          Text("Always force remote media")\n        }\n',
  ''
);

fs.writeFileSync(path, content);
console.log('done');
