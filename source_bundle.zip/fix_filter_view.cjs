const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineContentFilterView.swift';
let content = fs.readFileSync(path, 'utf8');

// Replace the contentFilter calls for the 4 properties with direct AppStorage ones
content = content.replace(
  '@State private var isEditingFilters = false',
  '@State private var isEditingFilters = false\n  @AppStorage("timeline_hide_posts_without_media") var hidePostsWithoutMedia: Bool = false\n  @AppStorage("timeline_hide_posts_with_media") var hidePostsWithMedia: Bool = false\n  @AppStorage("timeline_hide_status_text") var hideStatusText: Bool = false\n  @AppStorage("timeline_gallery_mode") var isGalleryMode: Bool = false'
);

content = content.replaceAll('contentFilter.hidePostsWithoutMedia', 'hidePostsWithoutMedia');
content = content.replaceAll('contentFilter.hidePostsWithMedia', 'hidePostsWithMedia');
content = content.replaceAll('contentFilter.hideStatusText', 'hideStatusText');
content = content.replaceAll('contentFilter.isGalleryMode', 'isGalleryMode');

fs.writeFileSync(path, content);
console.log('done');
