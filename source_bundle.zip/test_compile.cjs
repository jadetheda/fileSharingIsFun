const fs = require('fs');
const cp = require('child_process');

function check(file) {
  try {
    // We can't actually compile without swift, but we can check if we can run it?
    // Wait, swiftc is not available.
  } catch (e) {
  }
}
