const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(/getFilteredItems\(\)/g, 'getFilteredItems(seen: sessionSeenPosts)');

fs.writeFileSync(path, content);
console.log('done');
