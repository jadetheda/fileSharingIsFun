const fs = require('fs');
const file = 'ios-workspace/Packages/Notifications/Sources/Notifications/List/NotificationsListView.swift';
let content = fs.readFileSync(file, 'utf8');

// Add state
content = content.replace(
  '  @State private var isNotificationsPolicyPresented: Bool = false',
  '  @State private var isNotificationsPolicyPresented: Bool = false\n  @State private var isNotificationsContentFilterPresented: Bool = false\n  @State private var filter = NotificationsContentFilter.shared'
);

// Add button
content = content.replace(
  '        Divider()\n          ForEach(Notification.NotificationType.allCases, id: \\.self) { type in',
  `        Divider()
          Button {
            isNotificationsContentFilterPresented = true
          } label: {
            Label("Display Options", systemImage: "slider.horizontal.3")
          }
          .tint(theme.labelColor)
          Divider()
          ForEach(Notification.NotificationType.allCases, id: \\.self) { type in`
);

// Add sheet
content = content.replace(
  '    .sheet(isPresented: $isNotificationsPolicyPresented) {\n      NotificationsPolicyView()\n        .environment(client)\n        .environment(theme)\n    }',
  `    .sheet(isPresented: $isNotificationsPolicyPresented) {
      NotificationsPolicyView()
        .environment(client)
        .environment(theme)
    }
    .sheet(isPresented: $isNotificationsContentFilterPresented) {
      NotificationsContentFilterView()
        .environment(theme)
    }`
);

// Add onChange for filter
content = content.replace(
  '    .onChange(of: isNotificationsPolicyPresented) { _, isPresented in',
  `    .onChange(of: filter.showUpdate) { _, _ in refreshFiltered() }
    .onChange(of: filter.showStatus) { _, _ in refreshFiltered() }
    .onChange(of: filter.showMention) { _, _ in refreshFiltered() }
    .onChange(of: filter.showReblog) { _, _ in refreshFiltered() }
    .onChange(of: filter.showFollow) { _, _ in refreshFiltered() }
    .onChange(of: filter.showFollowRequest) { _, _ in refreshFiltered() }
    .onChange(of: filter.showFavourite) { _, _ in refreshFiltered() }
    .onChange(of: filter.showPoll) { _, _ in refreshFiltered() }
    .onChange(of: filter.showQuote) { _, _ in refreshFiltered() }
    .onChange(of: isNotificationsPolicyPresented) { _, isPresented in`
);

// Add refreshFiltered function
content = content.replace(
  '  private func applyFilter(type: Models.Notification.NotificationType?) {',
  `  private func refreshFiltered() {
    dataSource.reset()
    viewState = .loading
    Task {
      await fetchNotifications()
    }
  }

  private func applyFilter(type: Models.Notification.NotificationType?) {`
);

fs.writeFileSync(file, content);
