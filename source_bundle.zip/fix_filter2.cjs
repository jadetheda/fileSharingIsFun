const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/TimelineContentFilter.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/  @ObservationIgnored\n  private var _hideStatusText: Bool = false\n  public var hideStatusText: Bool \{\n    get \{\n      access\(keyPath: \\.hideStatusText\)\n      return _hideStatusText\n    \}\n    set \{\n      withMutation\(keyPath: \\.hideStatusText\) \{\n        _hideStatusText = newValue\n        storage.hideStatusText = newValue\n      \}\n    \}\n  \}\n/g, '');
fs.writeFileSync(file, content);
