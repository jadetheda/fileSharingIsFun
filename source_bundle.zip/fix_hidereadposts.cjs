const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

const regex = /func hideReadPosts\(\) async \{[\s\S]*?statusesState = \.displayWithGaps\(items: items, nextPageState: \.hasNextPage\) \/\/ nextPageState is approximate here\n    \}\n  \}/m;

const replaceStr = `func hideReadPosts() async {
    sessionSeenPosts = SeenPostsManager.shared.seenPosts
    
    var items = await datasource.getFilteredItems(seen: sessionSeenPosts)
    
    if items.count < 10, let client = client, let lastId = await datasource.get().last?.id {
      do {
        let newStatuses: [Status] = try await statusFetcher.fetchNextPage(
          client: client,
          timeline: timeline,
          lastId: lastId,
          offset: await datasource.get().count)
        await datasource.append(contentOf: newStatuses)
        StatusDataControllerProvider.shared.updateDataControllers(for: newStatuses, client: client)
        items = await datasource.getFilteredItems(seen: sessionSeenPosts)
      } catch { }
    }
    withAnimation {
      statusesState = .displayWithGaps(items: items, nextPageState: .hasNextPage) // nextPageState is approximate here
    }
  }`;

content = content.replace(regex, replaceStr);
fs.writeFileSync(path, content);
console.log('done');
