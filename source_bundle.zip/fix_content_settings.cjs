const fs = require('fs');
const path = 'ios-workspace/IceCubesApp/App/Tabs/Settings/ContentSettingsView.swift';
let content = fs.readFileSync(path, 'utf8');

const target = `        Toggle(isOn: $userPreferences.remoteMediaAutoFallback) {
          Text("Auto fallback to remote media (10s)")
        }
        Toggle(isOn: $userPreferences.remoteMediaAlwaysForce) {
          Text("Always force remote media")
        }`;

content = content.replace(target, '');
fs.writeFileSync(path, content);
console.log('done');
