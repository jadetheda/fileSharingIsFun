const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  '      if pullToRefresh, UserPreferences.shared.hideSeenPostsEnabled, (!UserPreferences.shared.hideSeenPostsIsToggle || TimelineContentFilter.shared.hideReadPosts) {\n        await datasource.hideReadPosts(seen: SeenPostsManager.shared.seenPosts, includeBoosts: UserPreferences.shared.hideSeenPostsIncludeBoosts)\n      }',
  '      if pullToRefresh, UserPreferences.shared.hideSeenPostsEnabled, (!UserPreferences.shared.hideSeenPostsIsToggle || TimelineContentFilter.shared.hideReadPosts) {\n        sessionSeenPosts = SeenPostsManager.shared.seenPosts\n      }'
);

fs.writeFileSync(path, content);
console.log('done');
