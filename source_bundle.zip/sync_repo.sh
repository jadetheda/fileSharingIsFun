#!/bin/bash
set -e

echo "Removing corrupted ios-workspace..."
rm -rf ios-workspace

echo "Cloning the latest copy from GitHub..."
git clone https://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@github.com/jadetheda/IceCubesApp.git ios-workspace

echo "Done."
