#!/bin/bash
set -e

if [ -z "$GITHUB_PAT" ]; then
  echo "Error: GITHUB_PAT environment variable is not set."
  exit 1
fi

echo "Removing corrupted ios-workspace..."
rm -rf ios-workspace
echo "Cloning the latest copy from GitHub..."
git clone https://${GITHUB_PAT}@github.com/jadetheda/IceCubesApp.git ios-workspace
echo "Done."
