const fs = require('fs');

// 1. Disable workflows
const workflowsDir = 'ios-workspace/.github/workflows';
['ios-build-distribute.yml', 'validate_translations.yml'].forEach(file => {
  const p = `${workflowsDir}/${file}`;
  if (fs.existsSync(p)) {
    let content = fs.readFileSync(p, 'utf8');
    content = content.replace(/push:\n\s+branches:/g, '# push:\n#    branches:');
    content = content.replace(/pull_request:\n\s+types:/g, '# pull_request:\n#    types:');
    fs.writeFileSync(p, content);
    console.log(`Disabled triggers in ${file}`);
  }
});

// 2. Disable UI polling
const appPath = 'src/App.tsx';
if (fs.existsSync(appPath)) {
  let content = fs.readFileSync(appPath, 'utf8');
  content = content.replace(
    /const fetchActionStatus = async \(\) => {/g,
    'const fetchActionStatus = async () => { return; // TEMPORARILY DISABLED\n'
  );
  content = content.replace(
    /\{actionStatus && \(/g,
    '{false && actionStatus && ('
  );
  fs.writeFileSync(appPath, content);
  console.log('Disabled action status polling in App.tsx');
}
