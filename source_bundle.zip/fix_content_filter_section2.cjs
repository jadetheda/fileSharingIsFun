const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineContentFilterView.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/          \}\n          if UserPreferences.shared.hideSeenPostsEnabled/g, '          }\n        Section {\n          if UserPreferences.shared.hideSeenPostsEnabled');
fs.writeFileSync(file, content);
