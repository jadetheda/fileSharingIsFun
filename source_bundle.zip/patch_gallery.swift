import SwiftUI

// Let's modify GalleryStatusesListView
