    let mediaStatuses = statuses.flatMap { $0.asMediaStatus }
    let columns = UserPreferences.shared.galleryColumns
    let gridItems = Array(repeating: GridItem(.flexible(), spacing: 4), count: columns)

    LazyVGrid(columns: gridItems, spacing: 4) {
      ForEach(mediaStatuses) { status in
        GalleryMediaCell(
          mediaStatus: status,
          routerPath: routerPath,
          client: client,
          isRemote: isRemote,
          filterContext: filterContext
        )
        .onAppear { fetcher.statusDidAppear(status: status.status) }
        .onDisappear { fetcher.statusDidDisappear(status: status.status) }
      }
    }
    .padding(.horizontal, 4)
