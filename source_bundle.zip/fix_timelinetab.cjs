const fs = require('fs');
const file = 'ios-workspace/IceCubesApp/App/Tabs/Timeline/TimelineTab.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(`      Divider()\n    }\n    timelineFiltersButtons`, `      Divider()\n    }\n    if preferences.showHidePostsWithoutMediaToggle {\n      Button {\n        if contentFilter.isGalleryMode {\n          contentFilter.isGalleryMode = false\n          contentFilter.hidePostsWithoutMedia = false\n        } else {\n          contentFilter.isGalleryMode = true\n          contentFilter.hidePostsWithoutMedia = true\n        }\n      } label: {\n        Label(contentFilter.isGalleryMode ? "Exit Gallery Mode" : "Gallery Mode", systemImage: "rectangle.grid.1x2")\n      }\n      Divider()\n    }\n    timelineFiltersButtons`);
fs.writeFileSync(file, content);
