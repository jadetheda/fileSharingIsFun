import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import { createRequire } from 'module';
import { checkIntegrity, updateManifest } from './integrity';

const require = createRequire(import.meta.url);
const archiver = require('archiver');

async function startServer() {
  const app = express();
  const PORT = 3000;
  
  app.use(express.json());

  app.get('/api/integrity/check', (req, res) => {
    console.log("HIT /api/integrity/check!");
    try {
      const result = checkIntegrity();
      res.json(result);
    } catch (e: any) {
      console.error("API ERROR:", e);
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/integrity/update', (req, res) => {
    try {
      const result = updateManifest();
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // API route to download the setup.sh script
  app.get('/api/setup', (req, res) => {
    const setupPath = path.join(process.cwd(), 'setup.sh');
    if (fs.existsSync(setupPath)) {
      res.download(setupPath, 'setup.sh');
    } else {
      res.status(404).send('Setup script not found');
    }
  });

  // API route to download a unified push bundle (ZIP containing push script + workspace)
  app.get('/api/download-push-bundle', async (req, res) => {
    try {
      const { corruptions } = checkIntegrity();
      if (corruptions.length > 0) {
        return res.status(400).send(`
          <html><body>
          <h2>Integrity Check Failed</h2>
          <p>The following binary files appear corrupted (hashes changed):</p>
          <ul>${corruptions.map(c => `<li>${c}</li>`).join('')}</ul>
          <p>Please resolve these corruptions or manually update the manifest before downloading.</p>
          </body></html>
        `);
      }
    } catch (e: any) {
      console.error('Integrity check error:', e);
    }

    const workspacePath = path.join(process.cwd(), 'ios-workspace');
    if (!fs.existsSync(workspacePath)) {
      fs.mkdirSync(workspacePath, { recursive: true });
    }

    res.attachment('push_bundle.zip');
    const { ZipArchive } = await import('archiver');
    const archive = new ZipArchive({ zlib: { level: 9 } });

    archive.on('error', (err: any) => {
      res.status(500).send({ error: err.message });
    });

    archive.pipe(res);

    // 1. Add the workspace folder contents
    archive.directory(workspacePath, 'ios-workspace');

    // 2. Generate the apply_and_push.sh script dynamically
    const scriptContent = `#!/bin/sh
set -e

GIT_NAME="AIStudio"
GIT_EMAIL="jmcelhoes@gmail.com"
GH_USER="jadetheda"
GH_REPO="IceCubesApp"

echo "Setting up git identity..."
git config --global user.name "$GIT_NAME"
git config --global user.email "$GIT_EMAIL"

if [ -z "$GITHUB_PAT" ]; then
  echo "Error: GITHUB_PAT environment variable is not set."
  echo "Please export your PAT before running this script: export GITHUB_PAT=your_token"
  exit 1
fi

REPO_URL="https://\${GH_USER}:\${GITHUB_PAT}@github.com/\${GH_USER}/\${GH_REPO}.git"
TMP_DIR="tmp_repo_$(date +%s)"

echo "Cloning repository..."
git clone --depth 1 "$REPO_URL" "$TMP_DIR"

echo "Applying Git safeguards against mobile extraction false positives..."
cd "$TMP_DIR"
git config core.fileMode false
git config core.autocrlf input
cd ..

echo "Copying workspace files into repository..."
# Copy contents from the bundled ios-workspace directory into the repo
cp -R ios-workspace/. "$TMP_DIR/"

cd "$TMP_DIR"

echo "Committing changes..."
git add .
if git diff --staged --quiet; then
  echo "No changes to push."
else
  git commit -m "Automated push from AI Studio Workspace"
  echo "Pushing changes..."
  git push origin HEAD
  echo "Push complete!"
fi

cd ..
echo "Cleaning up..."
rm -rf "$TMP_DIR"
echo "All done!"
`;
    archive.append(scriptContent, { name: 'apply_and_push.sh' });
    archive.finalize();
  });

  app.get('/api/git/status', (req, res) => {
    try {
      const workspacePath = path.join(process.cwd(), 'ios-workspace');
      const { execSync } = require('child_process');
      const statusOutput = execSync('git status --porcelain', { cwd: workspacePath }).toString().trim();
      
      let modifiedFiles: string[] = [];
      if (statusOutput) {
        modifiedFiles = statusOutput.split('\\n').map((line: string) => line.trim());
      }
      
      res.json({ success: true, modifiedFiles });
    } catch (e: any) {
      console.error('Git status error:', e);
      res.status(500).json({ error: e.message || 'Failed to get git status' });
    }
  });

  app.get('/api/git/action-status', async (req, res) => {
    try {
      const pat = process.env.GITHUB_PAT;
      if (!pat) {
        return res.status(401).json({ error: 'GITHUB_PAT not set' });
      }
      
      const response = await fetch('https://api.github.com/repos/jadetheda/IceCubesApp/actions/runs?per_page=1', {
        headers: {
          'Authorization': `token ${pat}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'AI-Studio-Agent'
        }
      });
      
      if (!response.ok) {
        throw new Error(`GitHub API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      if (data.workflow_runs && data.workflow_runs.length > 0) {
        const run = data.workflow_runs[0];
        res.json({
          success: true,
          status: run.status,
          conclusion: run.conclusion,
          html_url: run.html_url,
          name: run.name,
          updated_at: run.updated_at
        });
      } else {
        res.json({ success: true, status: 'no_runs', conclusion: null });
      }
    } catch (e: any) {
      console.error('Action status error:', e);
      res.status(500).json({ error: e.message || 'Failed to get action status' });
    }
  });

  app.post('/api/git/pull', (req, res) => {
    try {
      const workspacePath = path.join(process.cwd(), 'ios-workspace');
      const { execSync } = require('child_process');
      
      const pat = process.env.GITHUB_PAT;
      if (!pat) {
        throw new Error("GITHUB_PAT environment variable is missing.");
      }

      // We stash any local changes before pull to avoid conflicts, then pop them.
      // Or we can just try to pull and let it fail if it conflicts.
      // To keep it simple, just run git pull.
      const output = execSync(`git pull https://jadetheda:${pat}@github.com/jadetheda/IceCubesApp.git HEAD`, { cwd: workspacePath, stdio: 'pipe' }).toString();
      
      res.json({ success: true, output });
    } catch (e: any) {
      console.error('Git pull error:', e);
      res.status(500).json({ error: e.message || 'Failed to pull latest changes' });
    }
  });

  app.post('/api/git/reset', (req, res) => {
    try {
      const workspacePath = path.join(process.cwd(), 'ios-workspace');
      const { execSync } = require('child_process');
      const fs = require('fs');
      
      const pat = process.env.GITHUB_PAT;
      if (!pat) {
        throw new Error("GITHUB_PAT environment variable is missing.");
      }

      if (fs.existsSync(workspacePath)) {
        execSync(`rm -rf ios-workspace`, { cwd: process.cwd() });
      }
      
      // Clone again
      execSync(`git clone https://jadetheda:${pat}@github.com/jadetheda/IceCubesApp.git ios-workspace`, { cwd: process.cwd(), dot: true,
      dot: true, stdio: 'pipe' });
      
      res.json({ success: true, message: 'Workspace completely wiped and re-cloned.' });
    } catch (e: any) {
      console.error('Git reset error:', e);
      res.status(500).json({ error: e.message || 'Failed to reset workspace' });
    }
  });

  app.post('/api/push', (req, res) => {
    try {
      const workspacePath = path.join(process.cwd(), 'ios-workspace');
      const { execSync } = require('child_process');
      
      const commitMessage = req.body?.commitMessage || "Automated push from AI Studio Workspace";
      
      // Setup git config if needed
      execSync('git config user.name "AIStudio"', { cwd: workspacePath });
      execSync('git config user.email "jmcelhoes@gmail.com"', { cwd: workspacePath });
      
      execSync('git add .', { cwd: workspacePath });
      
      const pat = process.env.GITHUB_PAT;
      if (!pat) {
        throw new Error("GITHUB_PAT environment variable is missing. Please configure it in the AI Studio Secrets panel.");
      }
      
      let pushed = false;
      let newlyCommitted = false;
      try {
        const { execFileSync } = require('child_process');
        execFileSync('git', ['commit', '-m', commitMessage], { cwd: workspacePath, stdio: 'pipe' });
        newlyCommitted = true;
      } catch (err: any) {
        if (err.stdout && err.stdout.toString().includes('nothing to commit')) {
          // Ignore
        } else if (err.status !== 0 && !err.stdout) {
           const status = execSync('git status --porcelain', { cwd: workspacePath }).toString();
           if (status.trim() !== '') {
             throw err;
           }
        } else {
           throw err;
        }
      }
      
      const pushResult = execSync(`git push https://jadetheda:${pat}@github.com/jadetheda/IceCubesApp.git HEAD`, { cwd: workspacePath }).toString();
      if (!pushResult.includes("Everything up-to-date") || newlyCommitted) {
         pushed = true;
      } else {
         pushed = false; // Truly nothing to push
      }
      
      res.json({ success: true, pushed });
    } catch (e: any) {
      console.error('Push error:', e);
      res.status(500).json({ error: e.message || 'Push failed' });
    }
  });

  app.get('/api/download-source-bundle', async (req, res) => {
    res.attachment('source_bundle.zip');
    const { ZipArchive } = await import('archiver');
    const archive = new ZipArchive({ zlib: { level: 9 } });

    archive.on('error', (err: any) => {
      res.status(500).send({ error: err.message });
    });

    archive.pipe(res);

    archive.glob('**/*', {
      cwd: process.cwd(), dot: true,
      ignore: ['ios-workspace/**', 'node_modules/**', 'dist/**', '.git/**']
    });

    archive.finalize();
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
