const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  '  private(set) var timelineTask: Task<Void, Never>?',
  '  private(set) var timelineTask: Task<Void, Never>?\n  private var sessionSeenPosts: Set<String> = []'
);

fs.writeFileSync(path, content);
console.log('done');
