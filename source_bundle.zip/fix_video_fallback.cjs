const fs = require('fs');
const file = 'ios-workspace/Packages/MediaUI/Sources/MediaUI/MediaUIAttachmentVideoView.swift';
let content = fs.readFileSync(file, 'utf8');

// Replace the preparePlayer function to add observer
const replaceStr = `  func preparePlayer(autoPlay: Bool, isCompact: Bool) {
    player = .init(url: url)
    player?.audiovisualBackgroundPlaybackPolicy = .pauses
    #if !os(visionOS)
      player?.preventsDisplaySleepDuringVideoPlayback = false
    #endif
    if autoPlay || forceAutoPlay, !isCompact {
      player?.play()
      isPlaying = true
    } else {
      player?.pause()
      isPlaying = false
    }
    
    if let fallbackUrl = fallbackUrl {
      observer = player?.currentItem?.observe(\\.status, options: [.new]) { [weak self] item, _ in
        if item.status == .failed {
          Task { @MainActor in
            let wasPlaying = self?.isPlaying ?? false
            self?.player?.replaceCurrentItem(with: AVPlayerItem(url: fallbackUrl))
            if wasPlaying {
              self?.player?.play()
            }
          }
        }
      }
    }

    guard let player else { return }`;

content = content.replace(/  func preparePlayer\(autoPlay: Bool, isCompact: Bool\) \{[\s\S]*?guard let player else \{ return \}/, replaceStr);

fs.writeFileSync(file, content);
