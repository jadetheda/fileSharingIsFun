const fs = require('fs');

const types = ['Follow', 'FollowRequest', 'Mention', 'Reblog', 'Status', 'Favourite', 'Poll', 'Update', 'Quote', 'QuotedUpdate'];
const enumTypes = ['follow', 'follow_request', 'mention', 'reblog', 'status', 'favourite', 'poll', 'update', 'quote', 'quoted_update'];

let out = `import Foundation
import SwiftUI
import Observation
import Models

@MainActor
@Observable public class NotificationsContentFilter {
  public static let shared = NotificationsContentFilter()

  class Storage {
`;

for (let t of types) {
  out += `    @AppStorage("notifications_show_${t.toLowerCase()}") var show${t}: Bool = true\n`;
}

out += `  }

  private let storage = Storage()

`;

for (let t of types) {
  out += `  @ObservationIgnored
  private var _show${t}: Bool = true
  public var show${t}: Bool {
    get {
      access(keyPath: \\.show${t})
      return _show${t}
    }
    set {
      withMutation(keyPath: \\.show${t}) {
        _show${t} = newValue
        storage.show${t} = newValue
      }
    }
  }
`;
}

out += `
  private init() {
`;

for (let t of types) {
  out += `    _show${t} = storage.show${t}\n`;
}

out += `  }

  public func isTypeEnabled(_ type: Models.Notification.NotificationType?) -> Bool {
    guard let type = type else { return true }
    switch type {
`;

for (let i = 0; i < types.length; i++) {
  out += `    case .${enumTypes[i]}: return show${types[i]}\n`;
}

out += `    }
  }
}
`;

fs.writeFileSync('ios-workspace/Packages/Notifications/Sources/Notifications/NotificationsContentFilter.swift', out);
