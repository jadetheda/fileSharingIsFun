const fs = require('fs');
const path = 'ios-workspace/Packages/MediaUI/Sources/MediaUI/MediaUIAttachmentVideoView.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  'var player: AVPlayer?',
  'var player: AVPlayer?\n  private var observer: NSKeyValueObservation?'
);

content = content.replace(
  'let url: URL\n  let forceAutoPlay: Bool',
  'let url: URL\n  let fallbackUrl: URL?\n  let forceAutoPlay: Bool'
);

content = content.replace(
  'public init(url: URL, forceAutoPlay: Bool = false) {',
  'public init(url: URL, fallbackUrl: URL? = nil, forceAutoPlay: Bool = false) {'
);

content = content.replace(
  'self.url = url\n    self.forceAutoPlay = forceAutoPlay',
  'self.url = url\n    self.fallbackUrl = fallbackUrl\n    self.forceAutoPlay = forceAutoPlay'
);

const oldPrepare = `func preparePlayer(autoPlay: Bool, isCompact: Bool) {
    player = .init(url: url)
    player?.audiovisualBackgroundPlaybackPolicy = .pauses
    #if !os(visionOS)
      player?.preventsDisplaySleepDuringVideoPlayback = false
    #endif
    if autoPlay || forceAutoPlay, !isCompact {
      player?.play()
      isPlaying = true
    } else {
      player?.pause()
      isPlaying = false
    }

    guard let player else { return }

    NotificationCenter.default.addObserver(
      forName: .AVPlayerItemDidPlayToEndTime,
      object: player.currentItem, queue: .main
    ) { _ in
      Task { @MainActor [weak self] in
        if autoPlay || self?.forceAutoPlay == true {
          self?.play()
        }
      }
    }
  }`;

const newPrepare = `func preparePlayer(autoPlay: Bool, isCompact: Bool) {
    setupPlayer(for: url, autoPlay: autoPlay, isCompact: isCompact)
  }
  
  private func setupPlayer(for currentUrl: URL, autoPlay: Bool, isCompact: Bool) {
    player = .init(url: currentUrl)
    player?.audiovisualBackgroundPlaybackPolicy = .pauses
    #if !os(visionOS)
      player?.preventsDisplaySleepDuringVideoPlayback = false
    #endif
    if autoPlay || forceAutoPlay, !isCompact {
      player?.play()
      isPlaying = true
    } else {
      player?.pause()
      isPlaying = false
    }

    guard let player else { return }

    observer = player.currentItem?.observe(\\.status) { [weak self] item, _ in
        Task { @MainActor in
            if item.status == .failed, let fallbackUrl = self?.fallbackUrl, currentUrl != fallbackUrl {
                self?.setupPlayer(for: fallbackUrl, autoPlay: autoPlay, isCompact: isCompact)
            }
        }
    }

    NotificationCenter.default.addObserver(
      forName: .AVPlayerItemDidPlayToEndTime,
      object: player.currentItem, queue: .main
    ) { _ in
      Task { @MainActor [weak self] in
        if autoPlay || self?.forceAutoPlay == true {
          self?.play()
        }
      }
    }
  }`;

content = content.replace(oldPrepare, newPrepare);
fs.writeFileSync(path, content);
console.log('done');
