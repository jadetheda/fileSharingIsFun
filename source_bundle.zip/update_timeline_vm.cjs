const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  'if pullToRefresh, UserPreferences.shared.hideSeenPostsEnabled, UserPreferences.shared.hideSeenPostsIsToggle, TimelineContentFilter.shared.hideReadPosts {',
  'if UserPreferences.shared.hideSeenPostsEnabled, (!UserPreferences.shared.hideSeenPostsIsToggle || TimelineContentFilter.shared.hideReadPosts) {'
);

fs.writeFileSync(path, content);
console.log('done');
