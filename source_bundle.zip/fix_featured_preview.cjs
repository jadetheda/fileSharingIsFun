const fs = require('fs');
const path = 'ios-workspace/Packages/StatusKit/Sources/StatusKit/Row/Subviews/StatusRowMediaPreviewView.swift';
let content = fs.readFileSync(path, 'utf8');

// 1. Pass useRemoteMedia to FeaturedImagePreView
content = content.replace(
  '        FeaturedImagePreView(\n          attachment: attachments[0],\n          maxSize: imageMaxHeight == 300\n            ? nil\n            : CGSize(width: imageMaxHeight, height: imageMaxHeight),\n          sensitive: sensitive,\n          onLoaded: { loadedAttachments.insert(attachments[0].id) }\n        )',
  '        FeaturedImagePreView(\n          attachment: attachments[0],\n          useRemoteMedia: effectiveUseRemoteMedia,\n          maxSize: imageMaxHeight == 300\n            ? nil\n            : CGSize(width: imageMaxHeight, height: imageMaxHeight),\n          sensitive: sensitive,\n          onLoaded: { loadedAttachments.insert(attachments[0].id) }\n        )'
);

// 2. Add useRemoteMedia to FeaturedImagePreView definition
content = content.replace(
  '  let attachment: MediaAttachment\n  let maxSize: CGSize?\n  let sensitive: Bool\n  var onLoaded: () -> Void = {}',
  '  let attachment: MediaAttachment\n  let useRemoteMedia: Bool\n  let maxSize: CGSize?\n  let sensitive: Bool\n  var onLoaded: () -> Void = {}'
);

// 3. Update the url resolution in FeaturedImagePreView
content = content.replace(
  '  var body: some View {\n    if let url = attachment.url, let namespace = quickLook.namespace {',
  '  var body: some View {\n    let resolvedUrl = (useRemoteMedia ? (attachment.remoteUrl ?? attachment.url) : attachment.url)\n    if let url = resolvedUrl, let namespace = quickLook.namespace {'
);

content = content.replace(
  '                LazyResizableImage(url: attachment.url) { state in',
  '                LazyResizableImage(url: resolvedUrl) { state in'
);

fs.writeFileSync(path, content);
console.log('done');
