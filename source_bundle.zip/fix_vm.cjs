const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/  private var sessionSeenPosts: Set<String> = \[\]\n  private var sessionSeenPosts: Set<String> = \[\]/g, '  private var sessionSeenPosts: Set<String> = []');
fs.writeFileSync(file, content);
