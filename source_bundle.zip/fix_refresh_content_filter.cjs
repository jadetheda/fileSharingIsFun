const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(file, 'utf8');

const regex = /func refreshTimelineContentFilter\(\) async \{\s*timelineTask\?\.cancel\(\)\s*await updateStatusesState\(\)/g;
if (regex.test(content)) {
  content = content.replace(regex, `func refreshTimelineContentFilter() async {\n    timelineTask?.cancel()\n    if TimelineContentFilter.shared.hideReadPosts {\n      sessionSeenPosts = SeenPostsManager.shared.seenPosts\n    }\n    await updateStatusesState()`);
  fs.writeFileSync(file, content);
  console.log("Fixed refreshTimelineContentFilter!");
} else {
  console.log("Could not find regex in refreshTimelineContentFilter");
}
