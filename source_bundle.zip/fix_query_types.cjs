const fs = require('fs');
const file = 'ios-workspace/Packages/Notifications/Sources/Notifications/List/NotificationsListDataSource.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(
  /  private func queryTypes\(for selectedType: Models\.Notification\.NotificationType\?\) \-\> \[String\]\? \{\n    if let selectedType \{\n      var excludedTypes = Models\.Notification\.NotificationType\.allCases\n      excludedTypes\.removeAll\(where: \{ \$0 == selectedType \}\)\n      return excludedTypes\.map\(\\\.rawValue\)\n    \}\n    return nil\n  \}/g,
  `  private func queryTypes(for selectedType: Models.Notification.NotificationType?) -> [String]? {
    var excludedTypes = Models.Notification.NotificationType.allCases
    if let selectedType {
      excludedTypes.removeAll(where: { $0 == selectedType })
    } else {
      let filter = NotificationsContentFilter.shared
      excludedTypes = excludedTypes.filter { !filter.isTypeEnabled($0) }
    }
    return excludedTypes.isEmpty ? nil : excludedTypes.map(\\.rawValue)
  }`
);
fs.writeFileSync(file, content);
