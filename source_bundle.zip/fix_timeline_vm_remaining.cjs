const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

// Line 530 (hideReadPosts)
content = content.replace(
  '        let newStatuses: [Status] = try await statusFetcher.fetchNextPage(\n          client: client,\n          timeline: timeline,\n          lastId: lastId,\n          offset: await datasource.get().count)\n        await datasource.append(contentOf: newStatuses)',
  '        let newStatuses: [Status] = try await statusFetcher.fetchNextPage(\n          client: client,\n          timeline: timeline,\n          lastId: lastId,\n          offset: await datasource.get().count)\n        let filteredNewStatuses = filterSeenStatuses(from: newStatuses)\n        await datasource.append(contentOf: filteredNewStatuses)'
);

// Line 669 (autoFetchNextPagesIfFilteredEmpty)
content = content.replace(
  '      guard !newStatuses.isEmpty else { break }\n      await datasource.append(contentOf: newStatuses)\n      StatusDataControllerProvider.shared.updateDataControllers(for: newStatuses, client: client)',
  '      guard !newStatuses.isEmpty else { break }\n      let filteredNewStatuses = filterSeenStatuses(from: newStatuses)\n      await datasource.append(contentOf: filteredNewStatuses)\n      StatusDataControllerProvider.shared.updateDataControllers(for: newStatuses, client: client)'
);

fs.writeFileSync(path, content);
console.log('done');
