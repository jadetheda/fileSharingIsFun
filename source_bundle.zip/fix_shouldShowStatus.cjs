const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/actors/TimelineDatasource.swift';
let content = fs.readFileSync(file, 'utf8');

const regex = /(&&\s*!\(filter\.hidePostsFromBots\s*&&\s*isBotAuthored\))/g;
if (regex.test(content)) {
  content = content.replace(regex, `$1\n      && (!filter.hideReadPosts || !isSeen)`);
  fs.writeFileSync(file, content);
  console.log("Fixed shouldShowStatus!");
} else {
  console.log("Could not find regex in shouldShowStatus");
}
