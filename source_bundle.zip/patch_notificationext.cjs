const fs = require('fs');
const file = 'ios-workspace/Packages/Notifications/Sources/Notifications/Models/NotificationExt.swift';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/func consolidationId/g, 'nonisolated func consolidationId');
content = content.replace(/func isConsolidable/g, 'nonisolated func isConsolidable');

fs.writeFileSync(file, content);
console.log("Patched NotificationExt!");
