const fs = require('fs');
const path = 'ios-workspace/IceCubesApp/App/Tabs/Timeline/TimelineTab.swift';
let content = fs.readFileSync(path, 'utf8');

const target = `    if preferences.showHidePostsWithoutMediaToggle {
      Button {
        contentFilter.hidePostsWithoutMedia.toggle()
      } label: {
        Label(contentFilter.hidePostsWithoutMedia ? "Show posts without media" : "Hide posts without media", systemImage: "photo.on.rectangle.angled")
      }
      Divider()
    }`;

const replacement = `    if preferences.showHidePostsWithoutMediaToggle {
      Button {
        if !contentFilter.hidePostsWithoutMedia && !contentFilter.hidePostsWithMedia && !contentFilter.hideStatusText && !contentFilter.isGalleryMode {
          contentFilter.hidePostsWithoutMedia = true
          contentFilter.hidePostsWithMedia = false
          contentFilter.hideStatusText = false
          contentFilter.isGalleryMode = false
        } else if contentFilter.hidePostsWithoutMedia && !contentFilter.hideStatusText && !contentFilter.isGalleryMode {
          contentFilter.hidePostsWithoutMedia = true
          contentFilter.hidePostsWithMedia = false
          contentFilter.hideStatusText = true
          contentFilter.isGalleryMode = false
        } else if contentFilter.hidePostsWithoutMedia && contentFilter.hideStatusText && !contentFilter.isGalleryMode {
          contentFilter.hidePostsWithoutMedia = true
          contentFilter.hidePostsWithMedia = false
          contentFilter.hideStatusText = true
          contentFilter.isGalleryMode = true
        } else if contentFilter.isGalleryMode {
          contentFilter.hidePostsWithoutMedia = false
          contentFilter.hidePostsWithMedia = true
          contentFilter.hideStatusText = false
          contentFilter.isGalleryMode = false
        } else {
          contentFilter.hidePostsWithoutMedia = false
          contentFilter.hidePostsWithMedia = false
          contentFilter.hideStatusText = false
          contentFilter.isGalleryMode = false
        }
      } label: {
        if !contentFilter.hidePostsWithoutMedia && !contentFilter.hidePostsWithMedia && !contentFilter.hideStatusText && !contentFilter.isGalleryMode {
          Label("Show all posts", systemImage: "line.3.horizontal")
        } else if contentFilter.hidePostsWithoutMedia && !contentFilter.hideStatusText && !contentFilter.isGalleryMode {
          Label("Only posts with media", systemImage: "photo.on.rectangle.angled")
        } else if contentFilter.hidePostsWithoutMedia && contentFilter.hideStatusText && !contentFilter.isGalleryMode {
          Label("Only media (no text)", systemImage: "photo")
        } else if contentFilter.isGalleryMode {
          Label("Gallery mode", systemImage: "square.grid.2x2")
        } else {
          Label("Only text posts", systemImage: "text.alignleft")
        }
      }
      Divider()
    }`;

if (content.includes(target)) {
  content = content.replace(target, replacement);
  fs.writeFileSync(path, content);
  console.log("Updated TimelineTab.swift");
} else {
  console.log("Target not found in TimelineTab.swift");
}
