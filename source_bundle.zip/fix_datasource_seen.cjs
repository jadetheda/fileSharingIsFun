const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/actors/TimelineDatasource.swift';
let content = fs.readFileSync(path, 'utf8');

// We need to replace the actualSeen logic in both getFiltered and getFilteredItems
content = content.replace(
  '    let actualSeen: Set<String>?\n    if let seen {\n        actualSeen = seen\n    } else if snapshot.hideSeenPostsEnabled && snapshot.hideReadPosts {\n        actualSeen = await MainActor.run { SeenPostsManager.shared.seenPosts }\n    } else {\n        actualSeen = nil\n    }',
  '    let actualSeen = seen'
);
content = content.replace(
  '    let actualSeen: Set<String>?\n    if let seen {\n        actualSeen = seen\n    } else if snapshot.hideSeenPostsEnabled && snapshot.hideReadPosts {\n        actualSeen = await MainActor.run { SeenPostsManager.shared.seenPosts }\n    } else {\n        actualSeen = nil\n    }',
  '    let actualSeen = seen'
);

fs.writeFileSync(path, content);
console.log('done');
