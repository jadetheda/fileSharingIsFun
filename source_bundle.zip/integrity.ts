import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const MANIFEST_PATH = path.join(process.cwd(), 'workspace_manifest.json');
const WORKSPACE_DIR = path.join(process.cwd(), 'ios-workspace');

const BINARY_EXTENSIONS = [
  '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.webp',
  '.mp3', '.wav', '.ogg', '.m4a',
  '.mp4', '.mov', '.avi',
  '.zip', '.tar', '.gz', '.chd', '.bin', '.iso',
  '.ttf', '.otf', '.woff', '.woff2', '.eot'
];

export function getFileHash(filePath: string): string {
  const fileBuffer = fs.readFileSync(filePath);
  const hashSum = crypto.createHash('sha256');
  hashSum.update(fileBuffer);
  return hashSum.digest('hex');
}

export function getAllFiles(dirPath: string, arrayOfFiles: string[] = []) {
  if (!fs.existsSync(dirPath)) return arrayOfFiles;
  const files = fs.readdirSync(dirPath);

  files.forEach(function(file) {
    if (file === '.git') return;
    
    const fullPath = path.join(dirPath, file);
    if (fs.statSync(fullPath).isDirectory()) {
      arrayOfFiles = getAllFiles(fullPath, arrayOfFiles);
    } else {
      arrayOfFiles.push(fullPath);
    }
  });

  return arrayOfFiles;
}

export function checkIntegrity() {
  const allFiles = getAllFiles(WORKSPACE_DIR);
  const currentHashes: Record<string, string> = {};
  
  allFiles.forEach(file => {
    const relativePath = path.relative(WORKSPACE_DIR, file);
    currentHashes[relativePath] = getFileHash(file);
  });

  let manifest: Record<string, string> = {};
  if (fs.existsSync(MANIFEST_PATH)) {
    try {
      manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf-8'));
    } catch (e) {
      manifest = {};
    }
  } else {
    // Initial baseline
    fs.writeFileSync(MANIFEST_PATH, JSON.stringify(currentHashes, null, 2));
    
    // Save the baseline manifest backup
    const backupsDir = path.join(process.cwd(), 'manifest_backups');
    if (!fs.existsSync(backupsDir)) {
      fs.mkdirSync(backupsDir, { recursive: true });
    }
    fs.writeFileSync(path.join(backupsDir, 'workspace_manifest_baseline.json'), JSON.stringify(currentHashes, null, 2));

    return { status: 'baseline_created', changes: [], corruptions: [], missing: [], newFiles: [] };
  }

  const changes = [];
  const corruptions = [];
  const missing = [];
  const newFiles = [];

  // Check for modifications and corruptions
  for (const [file, hash] of Object.entries(currentHashes)) {
    if (manifest[file]) {
      if (manifest[file] !== hash) {
        const ext = path.extname(file).toLowerCase();
        if (BINARY_EXTENSIONS.includes(ext)) {
          corruptions.push(file); // Binaries shouldn't change naturally by agent
        } else {
          changes.push(file); // Text files might change legally
        }
      }
    } else {
      newFiles.push(file);
    }
  }

  // Check for missing files
  for (const [file, _hash] of Object.entries(manifest)) {
    if (!currentHashes[file]) {
      missing.push(file);
    }
  }

  return { status: 'checked', changes, corruptions, missing, newFiles };
}

export function updateManifest() {
  const allFiles = getAllFiles(WORKSPACE_DIR);
  const currentHashes: Record<string, string> = {};
  
  allFiles.forEach(file => {
    const relativePath = path.relative(WORKSPACE_DIR, file);
    currentHashes[relativePath] = getFileHash(file);
  });
  
  // Make a backup of the new manifest
  const backupsDir = path.join(process.cwd(), 'manifest_backups');
  if (!fs.existsSync(backupsDir)) {
    fs.mkdirSync(backupsDir, { recursive: true });
  }
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  fs.writeFileSync(path.join(backupsDir, `workspace_manifest_${timestamp}.json`), JSON.stringify(currentHashes, null, 2));

  fs.writeFileSync(MANIFEST_PATH, JSON.stringify(currentHashes, null, 2));
  return { status: 'updated' };
}
