const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  'await datasource.getFiltered(seen: SeenPostsManager.shared.seenPosts).first',
  'await datasource.getFiltered(seen: sessionSeenPosts).first'
);

fs.writeFileSync(path, content);
console.log('done');
