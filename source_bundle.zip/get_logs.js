async function main() {
  const pat = process.env.GITHUB_PAT;
  const runsResponse = await fetch('https://api.github.com/repos/jadetheda/IceCubesApp/actions/runs?status=failure&per_page=1', {
    headers: { 'Authorization': `token ${pat}`, 'Accept': 'application/vnd.github.v3+json', 'User-Agent': 'AI-Studio-Agent' }
  });
  const runsData = await runsResponse.json();
  const runId = runsData.workflow_runs[0].id;
  const jobsResponse = await fetch(`https://api.github.com/repos/jadetheda/IceCubesApp/actions/runs/${runId}/jobs`, {
    headers: { 'Authorization': `token ${pat}`, 'Accept': 'application/vnd.github.v3+json', 'User-Agent': 'AI-Studio-Agent' }
  });
  const jobsData = await jobsResponse.json();
  for (const job of jobsData.jobs) {
    if (job.conclusion === 'failure') {
      const logResponse = await fetch(job.url + '/logs', {
        headers: { 'Authorization': `token ${pat}`, 'Accept': 'application/vnd.github.v3+json', 'User-Agent': 'AI-Studio-Agent' },
        redirect: 'follow'
      });
      console.log(await logResponse.text());
    }
  }
}
main();
