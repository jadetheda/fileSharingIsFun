const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/TimelineContentFilter.swift';
let content = fs.readFileSync(file, 'utf8');

const targetStr = `    public init(
      showBoosts: Bool,
      showReplies: Bool,
      showThreads: Bool,
      showQuotePosts: Bool,
      hidePostsWithMedia: Bool,
      hidePostsWithoutMedia: Bool,
      hidePostsFromBots: Bool,
      isGalleryMode: Bool,
      hideReadPosts: Bool,
      hideSeenPostsEnabled: Bool,
      hideSeenPostsIncludeBoosts: Bool
    ) {`;

const replaceStr = `    public init(
      showBoosts: Bool = true,
      showReplies: Bool = true,
      showThreads: Bool = true,
      showQuotePosts: Bool = true,
      hidePostsWithMedia: Bool = false,
      hidePostsWithoutMedia: Bool = false,
      hidePostsFromBots: Bool = false,
      isGalleryMode: Bool = false,
      hideReadPosts: Bool = false,
      hideSeenPostsEnabled: Bool = false,
      hideSeenPostsIncludeBoosts: Bool = false
    ) {`;

if (content.includes(targetStr)) {
  content = content.replace(targetStr, replaceStr);
  fs.writeFileSync(file, content);
  console.log("Fixed Snapshot init");
} else {
  console.log("Could not find targetStr");
}
