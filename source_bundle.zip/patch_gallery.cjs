const fs = require('fs');
const file = 'ios-workspace/Packages/StatusKit/Sources/StatusKit/List/GalleryStatusesListView.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace('        case .gifv, .video:\n          MediaUIAttachmentVideoView(viewModel: .init(url: url))', '        case .gifv, .video:\n          MediaUIAttachmentVideoView(viewModel: .init(url: url))\n            .allowsHitTesting(false)');
fs.writeFileSync(file, content);
