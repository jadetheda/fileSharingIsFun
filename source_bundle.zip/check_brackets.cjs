const fs = require('fs');
const content = fs.readFileSync('ios-workspace/IceCubesApp/App/Tabs/Timeline/TimelineTab.swift', 'utf-8');
const lines = content.split('\n');
let depth = 0;
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  // ignore comments roughly
  let inString = false;
  for (let j = 0; j < line.length; j++) {
    if (line[j] === '"' && line[j-1] !== '\\') inString = !inString;
    if (!inString && line[j] === '/' && line[j+1] === '/') break;
    if (!inString && line[j] === '{') depth++;
    else if (!inString && line[j] === '}') {
      depth--;
      if (depth === 0) {
         console.log(`Struct closed at line ${i+1}`);
      }
    }
  }
}
console.log('Final depth:', depth);
