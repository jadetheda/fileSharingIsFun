const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineViewModel.swift';
let content = fs.readFileSync(path, 'utf8');

// 1. Add the helper function
const helper = `
  private func filterSeenStatuses(from statuses: [Status]) -> [Status] {
    if UserPreferences.shared.hideSeenPostsEnabled, (!UserPreferences.shared.hideSeenPostsIsToggle || TimelineContentFilter.shared.hideReadPosts) {
       let seen = SeenPostsManager.shared.seenPosts
       let includeBoosts = UserPreferences.shared.hideSeenPostsIncludeBoosts
       return statuses.filter { status in 
           if seen.contains(status.id) { return false }
           if includeBoosts, let reblog = status.reblog, seen.contains(reblog.id) { return false }
           return true
       }
    }
    return statuses
  }
`;

content = content.replace(
  '  private func updateDatasourceAndState(',
  helper + '\n  private func updateDatasourceAndState('
);

// 2. Use it in updateDatasourceAndState
content = content.replace(
  '    if replaceExisting {\n      await datasource.set(statuses)\n    } else {\n      await datasource.append(contentOf: statuses)\n    }',
  '    let filteredStatuses = filterSeenStatuses(from: statuses)\n    if replaceExisting {\n      await datasource.set(filteredStatuses)\n    } else {\n      await datasource.append(contentOf: filteredStatuses)\n    }'
);

// 3. Use it in fetchNextPage
content = content.replace(
  '    let newStatuses: [Status] = try await statusFetcher.fetchNextPage(\n      client: client,\n      timeline: timeline,\n      lastId: lastId,\n      offset: statuses.count)\n    await datasource.append(contentOf: newStatuses)',
  '    let newStatuses: [Status] = try await statusFetcher.fetchNextPage(\n      client: client,\n      timeline: timeline,\n      lastId: lastId,\n      offset: statuses.count)\n    let filteredNewStatuses = filterSeenStatuses(from: newStatuses)\n    await datasource.append(contentOf: filteredNewStatuses)'
);
// Also update the count used for autoFetchNextPagesIfFilteredEmpty to use newStatuses.count, which is correct, or filteredNewStatuses.count?
// Wait, newStatuses.count is better so it doesn't overfetch if everything was seen.

// 4. Use it in updateTimelineWithNewStatuses
content = content.replace(
  '    // Insert new statuses at the top\n    await datasource.insert(contentOf: newStatuses, at: 0)',
  '    // Insert new statuses at the top\n    let filteredNewStatuses = filterSeenStatuses(from: newStatuses)\n    await datasource.insert(contentOf: filteredNewStatuses, at: 0)'
);

fs.writeFileSync(path, content);
console.log('done');
