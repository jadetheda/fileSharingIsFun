#!/bin/bash
set -e

if [ -z "$1" ]; then
  echo "Usage: $0 <url-to-zip>"
  exit 1
fi

URL="$1"
ZIP_NAME="source_bundle_new.zip"
SCRIPT_NAME=$(basename "$0")

echo "Downloading $URL..."
npx -y node -e "
fetch('$URL')
  .then(r => {
    if (!r.ok) throw new Error('HTTP error ' + r.status);
    return r.arrayBuffer();
  })
  .then(b => require('fs').writeFileSync('$ZIP_NAME', Buffer.from(b)))
  .catch(err => { console.error(err); process.exit(1); });
"

if [ ! -f "$ZIP_NAME" ]; then
  echo "Failed to download the zip file."
  exit 1
fi

echo "Cleaning up old workspace files..."
echo "Preserving ios-workspace, node_modules, dotfiles, and scripts."

# Only delete visible items, keeping critical directories intact
find . -mindepth 1 -maxdepth 1 \
  ! -name ".*" \
  ! -name "$ZIP_NAME" \
  ! -name "$SCRIPT_NAME" \
  ! -name "node_modules" \
  ! -name "ios-workspace" \
  ! -name "setup.sh" \
  ! -name "sync_repo.sh" \
  -exec rm -rf {} +

echo "Extracting zip..."
unzip -o "$ZIP_NAME"

echo "Cleaning up zip..."
rm "$ZIP_NAME"

echo "Workspace replaced successfully!"
