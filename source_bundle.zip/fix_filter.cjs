const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/TimelineContentFilter.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/    @ObservationIgnored\n    get {\n    }\n    set {\n      }\n    }\n  }/g, 
`  @ObservationIgnored
  private var _hideStatusText: Bool = false
  public var hideStatusText: Bool {
    get {
      access(keyPath: \\.hideStatusText)
      return _hideStatusText
    }
    set {
      withMutation(keyPath: \\.hideStatusText) {
        _hideStatusText = newValue
        storage.hideStatusText = newValue
      }
    }
  }`);
fs.writeFileSync(file, content);
