const fs = require('fs');
const file = 'ios-workspace/Packages/Notifications/Sources/Notifications/Row/NotificationRowAppendTextView.swift';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/func NotificationRowAppendTextView/g, 'nonisolated func NotificationRowAppendTextView');

fs.writeFileSync(file, content);
console.log("Patched NotificationRowAppendTextView!");
