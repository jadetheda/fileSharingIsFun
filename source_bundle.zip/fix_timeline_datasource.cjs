const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/actors/TimelineDatasource.swift';
let content = fs.readFileSync(path, 'utf8');

const target = `    let actualSeen: Set<String>?
    if let seen {
        actualSeen = seen
    } else if snapshot.hideSeenPostsEnabled && snapshot.hideReadPosts {
        actualSeen = await MainActor.run { SeenPostsManager.shared.seenPosts }
    } else {
        actualSeen = nil
    }`;

const replacement = `    let actualSeen: Set<String>? = seen`;

content = content.replace(target, replacement);

const target2 = `    let hideSeenPostsIncludeBoosts = filter.hideSeenPostsIncludeBoosts
    var isSeen = seen?.contains(status.id) ?? false
    if hideSeenPostsIncludeBoosts, let reblog = status.reblog {
      if seen?.contains(reblog.id) == true {
        isSeen = true
      }
    }`;

// Wait, the shouldShowStatus method can still check isSeen if it is provided.
// So we don't need to change shouldShowStatus.

fs.writeFileSync(path, content);
console.log('done');
