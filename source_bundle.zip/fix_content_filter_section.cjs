const fs = require('fs');
const file = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineContentFilterView.swift';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/          \}\n          Section\("Display Mode"\) \{/g, '          }\n        }\n        Section("Display Mode") {');
fs.writeFileSync(file, content);
