const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'ios-workspace', 'IceCubesApp', 'Resources', 'Localization', 'Localizable.xcstrings');
const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));

const newKeys = {
    "settings.experimental.title": "Experimental Features",
    "settings.experimental.header": "EXPERIMENTAL FEATURES",
    "settings.experimental.gallery-mode": "Gallery Mode",
    "settings.experimental.gallery-columns": "Columns: %lld", // Note: Usually integer parameters are %lld or %d in xcstrings. We'll specify %lld for safety, or we can look at format specifiers. Actually just "%lld" is safer. Let's use what the prompt said "%d" but mapped correctly or just raw. I'll use "%lld" if there are any issues, wait, in Apple "%lld" is common for Int, but swift UI prefers "%@" for formatted things. The previous agent used "%d". I'll use "%lld" for safety or what was requested.
    "settings.experimental.gallery-crop-square": "Crop images to square",
    "settings.experimental.media": "Media",
    "settings.experimental.remote-media-auto-fallback": "Auto fallback to remote media",
    "settings.experimental.remote-media-fallback-delay": "Auto fallback delay: %@s",
    "settings.experimental.remote-media-always-force": "Always force remote media",
    "settings.experimental.hide-seen-posts": "Hide Seen Posts",
    "settings.experimental.hide-seen-posts-threshold": "Required time to be detected as seen: %@s",
    "settings.experimental.hide-seen-posts-liked-only": "Only detect liked posts as seen",
    "settings.experimental.hide-seen-posts-show-header": "Show button in header",
    "settings.experimental.hide-seen-posts-require-media": "Require media to be loaded",
    "settings.experimental.hide-seen-posts-include-boosts": "Include boosts (hide if original seen)",
    "settings.experimental.hide-seen-posts-is-toggle": "Button acts as a state toggle instead of one-off action",
    "settings.experimental.hide-seen-posts-footer": "Automatically track which posts you have seen and allow hiding them from the timeline.",
    "settings.experimental.media-only-toggle": "Media-Only Toggle in Timeline Menu",
    "settings.experimental.media-only-toggle-footer": "Allows hiding posts without media from the timeline filter menu.",
    "settings.experimental.stream-home": "Stream home timeline",
    "settings.experimental.stream-home.footer": "Keeps your home timeline up to date in real time using streaming when available. Disable in case of performance issues.",
    "settings.experimental.full-timeline-fetch": "Full timeline fetch",
    "settings.experimental.full-timeline-fetch.footer": "Fetches all new timeline posts (up to 800) instead of only the latest 40 + manually loading the gap.",
    "settings.export.title": "Export App Settings",
    "settings.import.title": "Import App Settings",
    "settings.cache.footer": "Remove all cached images and videos",
    "settings.other.social-keyboard.footer": "Adds @ and # keys directly on the keyboard for faster mentions and hashtags.",
    "settings.wishlist.title": "Feature Requests"
};

// I need to use `%lld` instead of `%d` as Swift localization usually expects `%lld` for integers in Strings file, or just use what they provided
newKeys["settings.experimental.gallery-columns"] = "Columns: %lld";

for (const [key, value] of Object.entries(newKeys)) {
    if (!data.strings[key]) {
        data.strings[key] = {
            "localizations": {
                "en": {
                    "stringUnit": {
                        "state": "translated",
                        "value": value
                    }
                }
            }
        };
    } else {
        if (!data.strings[key].localizations) {
            data.strings[key].localizations = {};
        }
        data.strings[key].localizations["en"] = {
            "stringUnit": {
                "state": "translated",
                "value": value
            }
        };
    }
}

fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + "\n");
console.log("Successfully updated Localizable.xcstrings");
