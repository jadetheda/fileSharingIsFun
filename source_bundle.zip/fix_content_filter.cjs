const fs = require('fs');
const path = 'ios-workspace/Packages/Timeline/Sources/Timeline/View/TimelineContentFilterView.swift';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  '  @AppStorage("timeline_hide_posts_without_media") var hidePostsWithoutMedia: Bool = false\n  @AppStorage("timeline_hide_posts_with_media") var hidePostsWithMedia: Bool = false\n  @AppStorage("timeline_hide_status_text") var hideStatusText: Bool = false\n  @AppStorage("timeline_gallery_mode") var isGalleryMode: Bool = false\n',
  ''
);

content = content.replace(/hidePostsWithoutMedia/g, 'contentFilter.hidePostsWithoutMedia');
content = content.replace(/hidePostsWithMedia/g, 'contentFilter.hidePostsWithMedia');
content = content.replace(/hideStatusText/g, 'contentFilter.hideStatusText');
content = content.replace(/isGalleryMode/g, 'contentFilter.isGalleryMode');
// However, the above replace will also replace contentFilter.hidePostsWithoutMedia to contentFilter.contentFilter.hidePostsWithoutMedia if it already had contentFilter.
// Let's just fix that:
content = content.replace(/contentFilter\.contentFilter\./g, 'contentFilter.');

fs.writeFileSync(path, content);
console.log('done');
