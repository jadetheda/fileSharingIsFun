import { Download, Terminal, ShieldAlert, ShieldCheck, RefreshCw, CheckCircle2, AlertCircle, XCircle } from 'lucide-react';
import { useState, useEffect } from 'react';

function IntegrityCheck() {
  const [status, setStatus] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [showConfirmUpdate, setShowConfirmUpdate] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<{type: 'success' | 'error' | null, message: string}>({type: null, message: ''});

  const checkIntegrity = async () => {
    setLoading(true);
    setUpdateStatus({type: null, message: ''});
    try {
      const res = await fetch('/api/integrity/check');
      if (!res.ok) {
        let errMsg = 'Network error';
        try {
          const errData = await res.json();
          errMsg = errData.error || errMsg;
        } catch (_) {
          errMsg = await res.text();
        }
        throw new Error(errMsg);
      }
      const data = await res.json();
      setStatus(data);
    } catch (e: any) {
      console.error(e);
      setStatus({ error: e.message });
    }
    setLoading(false);
  };

  const updateManifest = async () => {
    setLoading(true);
    setShowConfirmUpdate(false);
    setUpdateStatus({type: null, message: ''});
    try {
      const res = await fetch('/api/integrity/update', { method: 'POST' });
      if (!res.ok) {
        let errMsg = 'Network error';
        try {
          const errData = await res.json();
          errMsg = errData.error || errMsg;
        } catch (_) {
          errMsg = await res.text();
        }
        throw new Error(errMsg);
      }
      await checkIntegrity();
      setUpdateStatus({type: 'success', message: 'Manifest updated successfully. Baseline is now current.'});
      setTimeout(() => setUpdateStatus({type: null, message: ''}), 6000);
    } catch (e: any) {
      console.error(e);
      setUpdateStatus({type: 'error', message: e.message});
    }
    setLoading(false);
  };

  useEffect(() => {
    checkIntegrity();
  }, []);

  if (!status) return <div className="text-sm text-neutral-500 mt-6">Checking workspace integrity...</div>;
  if (status.error) return <div className="text-sm text-red-500 mt-6">Error: {status.error}</div>;

  const hasIssues = status.corruptions?.length > 0;
  const hasChanges = status.changes?.length > 0 || status.newFiles?.length > 0 || status.missing?.length > 0;

  return (
    <div className="mt-8 pt-6 border-t border-neutral-800">
      <div className="flex items-center gap-2 mb-4">
        {hasIssues ? (
          <ShieldAlert className="w-5 h-5 text-red-500 flex-shrink-0" />
        ) : (
          <ShieldCheck className="w-5 h-5 text-green-500 flex-shrink-0" />
        )}
        <h3 className="text-sm font-medium text-white">Workspace Integrity</h3>
        {loading && <RefreshCw className="w-3 h-3 text-neutral-500 animate-spin ml-auto" />}
      </div>
      
      <div className="space-y-3 mb-4">
        <div className={`p-3 rounded-xl border ${hasIssues ? 'bg-red-950/30 border-red-900/50 text-red-400' : 'bg-neutral-800/50 border-neutral-800 text-neutral-400'}`}>
          <div className="flex items-start gap-2">
            <div className="text-sm w-full">
              <span className="font-medium">{hasIssues ? 'Corruptions Detected' : 'All Binary Files Intact'}</span>
              {hasIssues && (
                <ul className="mt-2 space-y-1 text-xs opacity-80 list-disc pl-4">
                  {status.corruptions?.map((c: string) => <li key={c}>{c}</li>)}
                </ul>
              )}
            </div>
          </div>
        </div>

        {hasChanges && (
          <div className="p-3 rounded-xl border bg-yellow-950/30 border-yellow-900/50 text-yellow-500">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <div className="text-sm w-full">
                <span className="font-medium">Uncommitted File Changes</span>
                <ul className="mt-2 space-y-1 text-xs opacity-80 list-disc pl-4">
                  {status.changes?.slice(0, 3).map((c: string) => <li key={c} className="truncate">{c}</li>)}
                  {status.newFiles?.slice(0, 3).map((c: string) => <li key={c} className="truncate">{c} (New)</li>)}
                  {status.missing?.slice(0, 3).map((c: string) => <li key={c} className="truncate">{c} (Missing)</li>)}
                  {(status.changes?.length + status.newFiles?.length + status.missing?.length) > 3 && (
                    <li>...and more</li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {updateStatus.type && (
        <div className={`mb-4 p-3 rounded-xl border text-sm flex items-start gap-2 ${updateStatus.type === 'success' ? 'bg-green-950/30 border-green-900/50 text-green-400' : 'bg-red-950/30 border-red-900/50 text-red-400'}`}>
          {updateStatus.type === 'success' ? <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" /> : <XCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />}
          <span>{updateStatus.message}</span>
        </div>
      )}

      {showConfirmUpdate ? (
        <div className="p-3 rounded-xl border border-red-900/50 bg-red-950/30 mb-4">
          <p className="text-xs text-red-400 mb-3">Are you sure you want to update the integrity baseline? This will accept all current changes as the new source of truth.</p>
          <div className="flex gap-2">
            <button
              onClick={updateManifest}
              disabled={loading}
              className="flex-1 px-3 py-2 bg-red-600 text-white text-xs font-medium rounded-lg hover:bg-red-500 disabled:opacity-50 transition-colors"
            >
              Confirm Update
            </button>
            <button
              onClick={() => setShowConfirmUpdate(false)}
              disabled={loading}
              className="flex-1 px-3 py-2 bg-neutral-800 text-white text-xs font-medium rounded-lg hover:bg-neutral-700 disabled:opacity-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <button
            onClick={checkIntegrity}
            disabled={loading}
            className="flex items-center justify-center gap-1.5 flex-1 px-3 py-2 bg-neutral-800 text-neutral-300 text-xs rounded-lg hover:bg-neutral-700 disabled:opacity-50 transition-colors"
          >
            <RefreshCw className={loading ? 'w-3 h-3 animate-spin' : 'w-3 h-3'} />
            Re-check
          </button>
          {(hasIssues || hasChanges) && (
            <button
              onClick={() => setShowConfirmUpdate(true)}
              disabled={loading}
              className="flex-1 px-3 py-2 bg-blue-600 text-white text-xs rounded-lg hover:bg-blue-500 disabled:opacity-50 transition-colors"
            >
              Update Manifest
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [isPushing, setIsPushing] = useState(false);
  const [pushStatus, setPushStatus] = useState<{ type: 'success' | 'error' | null, message: string }>({ type: null, message: '' });
  const [showConfirmPush, setShowConfirmPush] = useState(false);
  const [commitMessage, setCommitMessage] = useState('');
  
  const [modifiedFiles, setModifiedFiles] = useState<string[] | null>(null);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  
  const [isWiping, setIsWiping] = useState(false);
  const [showWipeConfirm, setShowWipeConfirm] = useState(false);
  const [wipeConfirmText, setWipeConfirmText] = useState('');

  const [actionStatus, setActionStatus] = useState<{status: string, conclusion: string, url: string} | null>(null);

  const fetchActionStatus = async () => {
    try {
      const res = await fetch('/api/git/action-status');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.status !== 'no_runs') {
          setActionStatus({ status: data.status, conclusion: data.conclusion, url: data.html_url });
        }
      }
    } catch (e) {
      // ignore
    }
  };

  useEffect(() => {
    // fetchActionStatus();
    // const interval = setInterval(fetchActionStatus, 30000); // Check every 30 seconds
    // return () => clearInterval(interval);
  }, []);

  const wipeWorkspace = async () => {
    setIsWiping(true);
    setPushStatus({ type: null, message: '' });
    try {
      const res = await fetch('/api/git/reset', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setPushStatus({ type: 'success', message: 'Workspace completely wiped and re-cloned.' });
        setShowWipeConfirm(false);
        setWipeConfirmText('');
        setModifiedFiles(null);
      } else {
        setPushStatus({ type: 'error', message: data.error || 'Failed to wipe workspace' });
      }
    } catch (e: any) {
      setPushStatus({ type: 'error', message: 'Wipe request failed: ' + e.message });
    }
    setIsWiping(false);
  };

  const checkStatus = async () => {
    setIsCheckingStatus(true);
    setPushStatus({ type: null, message: '' });
    try {
      const res = await fetch('/api/git/status');
      const data = await res.json();
      if (data.success) {
        setModifiedFiles(data.modifiedFiles);
        if (data.modifiedFiles.length === 0) {
          setPushStatus({ type: 'success', message: 'No modified files. Working tree is clean.' });
        }
      } else {
        setPushStatus({ type: 'error', message: data.error || 'Failed to check status' });
      }
    } catch (e: any) {
      setPushStatus({ type: 'error', message: 'Status request failed: ' + e.message });
    }
    setIsCheckingStatus(false);
  };

  const pullLatest = async () => {
    setIsPulling(true);
    setPushStatus({ type: null, message: '' });
    try {
      const res = await fetch('/api/git/pull', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setPushStatus({ type: 'success', message: 'Successfully pulled latest changes.' });
      } else {
        setPushStatus({ type: 'error', message: data.error || 'Failed to pull' });
      }
    } catch (e: any) {
      setPushStatus({ type: 'error', message: 'Pull request failed: ' + e.message });
    }
    setIsPulling(false);
  };

  const handlePush = async () => {
    setShowConfirmPush(false);
    setIsPushing(true);
    setPushStatus({ type: null, message: '' });
    
    try {
      const res = await fetch('/api/push', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ commitMessage })
      });
      const data = await res.json();
      if (data.success) {
        setPushStatus({ type: 'success', message: data.pushed ? 'Successfully pushed to GitHub!' : 'No changes to push.' });
        setCommitMessage('');
        setModifiedFiles(null);
      } else {
        setPushStatus({ type: 'error', message: data.error || 'Unknown error occurred.' });
      }
    } catch (e: any) {
      setPushStatus({ type: 'error', message: 'Request failed: ' + e.message });
    }
    
    setIsPushing(false);
  };

  return (
    <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full bg-neutral-900 rounded-2xl shadow-lg border border-neutral-800 p-8 mb-4">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-semibold text-white mb-2">iOS Workspace</h1>
          <p className="text-sm text-neutral-400">
            Develop and push native iOS applications directly from AI Studio using GitHub Actions.
          </p>
        </div>
        
        <div className="space-y-4">
          {pushStatus.type && (
            <div className={`p-3 rounded-xl border text-sm flex items-start gap-2 ${pushStatus.type === 'success' ? 'bg-green-950/30 border-green-900/50 text-green-400' : 'bg-red-950/30 border-red-900/50 text-red-400'}`}>
              {pushStatus.type === 'success' ? <CheckCircle2 className="w-5 h-5 flex-shrink-0" /> : <XCircle className="w-5 h-5 flex-shrink-0" />}
              <span className="mt-0.5">{pushStatus.message}</span>
            </div>
          )}

          {modifiedFiles && modifiedFiles.length > 0 && (
            <div className="p-3 rounded-xl border bg-neutral-800/50 border-neutral-800 text-neutral-300">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-400" />
                <div className="text-sm w-full">
                  <span className="font-medium text-blue-400">Modified Files ({modifiedFiles.length})</span>
                  <ul className="mt-2 space-y-1 text-xs opacity-80 list-disc pl-4 max-h-32 overflow-y-auto">
                    {modifiedFiles.map((c: string) => <li key={c} className="truncate">{c}</li>)}
                  </ul>
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <button 
              onClick={checkStatus}
              disabled={isCheckingStatus || isPushing || isPulling}
              className="flex-1 px-4 py-2 bg-neutral-800 text-white text-sm rounded-xl font-medium hover:bg-neutral-700 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isCheckingStatus ? 'animate-spin' : ''}`} />
              Check Status
            </button>
            <button 
              onClick={pullLatest}
              disabled={isCheckingStatus || isPushing || isPulling}
              className="flex-1 px-4 py-2 bg-neutral-800 text-white text-sm rounded-xl font-medium hover:bg-neutral-700 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
            >
              <Download className={`w-4 h-4 ${isPulling ? 'animate-pulse' : ''}`} />
              Pull Latest
            </button>
          </div>

          {showConfirmPush ? (
            <div className="p-4 rounded-xl border border-blue-900/50 bg-blue-950/30">
              <p className="text-sm text-blue-200 mb-3">You are about to commit and push all workspace changes to GitHub.</p>
              <input 
                type="text" 
                value={commitMessage}
                onChange={(e) => setCommitMessage(e.target.value)}
                placeholder="Commit message (optional)"
                className="w-full bg-neutral-900 border border-blue-900/50 rounded-lg px-3 py-2 text-sm text-white placeholder-blue-300/50 mb-4 focus:outline-none focus:border-blue-500"
              />
              <div className="flex gap-2">
                <button
                  onClick={handlePush}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-500 transition-colors"
                >
                  Yes, Push
                </button>
                <button
                  onClick={() => setShowConfirmPush(false)}
                  className="flex-1 px-4 py-2 bg-neutral-800 text-white rounded-lg font-medium hover:bg-neutral-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button 
              onClick={() => {
                setPushStatus({ type: null, message: '' });
                setShowConfirmPush(true);
              }}
              disabled={isPushing || isCheckingStatus || isPulling}
              className="flex items-center justify-center w-full gap-2 px-4 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-500 disabled:opacity-50 transition-colors"
            >
              {isPushing ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <ShieldCheck className="w-5 h-5" />
              )}
              {isPushing ? 'Pushing to GitHub...' : 'Push Directly to GitHub'}
            </button>
          )}

          {false && actionStatus && (
            <div className="mt-2 flex items-center justify-center gap-2 text-xs text-neutral-500">
              {actionStatus.status === 'in_progress' || actionStatus.status === 'queued' ? (
                <RefreshCw className="w-3 h-3 animate-spin text-blue-400" />
              ) : actionStatus.conclusion === 'success' ? (
                <CheckCircle2 className="w-3 h-3 text-green-500" />
              ) : (
                <XCircle className="w-3 h-3 text-red-500" />
              )}
              <a href={actionStatus.url} target="_blank" rel="noreferrer" className="hover:text-neutral-300 hover:underline transition-colors">
                Action: {actionStatus.status === 'completed' ? actionStatus.conclusion : actionStatus.status}
              </a>
            </div>
          )}
        </div>

        <IntegrityCheck />
        
        <div className="mt-8 pt-6 border-t border-neutral-800">
          {showWipeConfirm ? (
            <div className="p-4 rounded-xl border border-red-900/50 bg-red-950/30">
              <div className="flex items-start gap-2 mb-3">
                <ShieldAlert className="w-5 h-5 text-red-500 flex-shrink-0" />
                <div>
                  <h3 className="text-sm font-medium text-red-400">Danger Zone</h3>
                  <p className="text-xs text-red-300/80 mt-1">This will permanently delete the current workspace and clone a fresh copy. All uncommitted changes will be lost.</p>
                </div>
              </div>
              <p className="text-xs text-red-300 font-medium mb-2">Type "WIPE WORKSPACE" to confirm:</p>
              <input 
                type="text" 
                value={wipeConfirmText}
                onChange={(e) => setWipeConfirmText(e.target.value)}
                placeholder="WIPE WORKSPACE"
                className="w-full bg-neutral-900 border border-red-900/50 rounded-lg px-3 py-2 text-sm text-white placeholder-red-300/30 mb-4 focus:outline-none focus:border-red-500 font-mono"
              />
              <div className="flex gap-2">
                <button
                  onClick={wipeWorkspace}
                  disabled={wipeConfirmText !== 'WIPE WORKSPACE' || isWiping}
                  className="flex-1 px-4 py-2 bg-red-600 text-white text-sm rounded-lg font-medium hover:bg-red-500 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                >
                  {isWiping ? <RefreshCw className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                  Hard Reset
                </button>
                <button
                  onClick={() => {
                    setShowWipeConfirm(false);
                    setWipeConfirmText('');
                  }}
                  disabled={isWiping}
                  className="flex-1 px-4 py-2 bg-neutral-800 text-white text-sm rounded-lg font-medium hover:bg-neutral-700 disabled:opacity-50 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <button
                onClick={() => window.location.href = '/api/download-source-bundle'}
                className="flex items-center justify-center w-full gap-2 px-4 py-3 bg-neutral-800/80 text-white rounded-xl font-medium hover:bg-neutral-700 transition-colors text-sm border border-neutral-700"
              >
                <Download className="w-4 h-4" />
                Export Web Codebase ZIP
              </button>
              
              <button
                onClick={() => setShowWipeConfirm(true)}
                className="flex items-center justify-center w-full gap-2 px-4 py-3 bg-red-950/20 text-red-500 rounded-xl font-medium hover:bg-red-950/40 transition-colors text-sm border border-transparent hover:border-red-900/30"
              >
                <ShieldAlert className="w-4 h-4" />
                Hard Reset Workspace
              </button>
            </div>
          )}
        </div>
      </div>
      
    </div>
  );
}