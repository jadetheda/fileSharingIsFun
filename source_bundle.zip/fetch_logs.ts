import fetch from 'node-fetch';

async function main() {
  const pat = process.env.GITHUB_PAT;
  if (!pat) {
    console.error('No GITHUB_PAT');
    return;
  }

  try {
    const runsResponse = await fetch('https://api.github.com/repos/jadetheda/IceCubesApp/actions/runs?status=failure&per_page=1', {
      headers: {
        'Authorization': `token ${pat}`,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'AI-Studio-Agent'
      }
    });

    const runsData = await runsResponse.json();
    if (!runsData.workflow_runs || runsData.workflow_runs.length === 0) {
      console.log('No failed runs found.');
      return;
    }

    const runId = runsData.workflow_runs[0].id;
    console.log(`Found failed run ID: ${runId}`);

    const jobsResponse = await fetch(`https://api.github.com/repos/jadetheda/IceCubesApp/actions/runs/${runId}/jobs`, {
      headers: {
        'Authorization': `token ${pat}`,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'AI-Studio-Agent'
      }
    });

    const jobsData = await jobsResponse.json();
    for (const job of jobsData.jobs) {
      if (job.conclusion === 'failure') {
        console.log(`Job failed: ${job.name}`);
        const logResponse = await fetch(job.url + '/logs', {
          headers: {
            'Authorization': `token ${pat}`,
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'AI-Studio-Agent'
          },
          redirect: 'follow'
        });
        
        if (logResponse.ok) {
           const logText = await logResponse.text();
           console.log(`Logs for ${job.name} (last 100 lines):`);
           console.log(logText.split('\\n').slice(-100).join('\\n'));
        } else {
           console.log('Failed to fetch logs', logResponse.status);
        }
      }
    }

  } catch (e) {
    console.error(e);
  }
}

main();
