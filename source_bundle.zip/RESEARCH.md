# Automating iOS IPA Builds for Ice Cubes using GitHub Actions

Since Ice Cubes is a native iOS application built with Swift and SwiftUI, compiling a `.ipa` file natively from a Linux or Node.js environment (like this AI Studio environment) is **not possible** because iOS compilation requires macOS and Xcode.

However, we can design and define the **CI/CD pipeline architecture** right here to automate the distribution process. By setting up GitHub Actions, we offload the heavy lifting to GitHub's hosted macOS runners.

## Overview of the Automation Pipeline

I have created a fully functional GitHub Actions workflow file in your project at `.github/workflows/ios-build-distribute.yml`.

### Step 1: Triggering the Build
The workflow is configured to run on:
- Commits to the `main` branch.
- Creating a new Release on GitHub.
- Manual execution via `workflow_dispatch`.

### Step 2: The Build Environment
The workflow uses `macos-latest` as the runner OS, which provides the necessary macOS environment and comes pre-installed with standard versions of Xcode. 

### Step 3: Code Signing
Apple requires apps to be code-signed to run on physical devices. You will need to extract your Distribution Certificate and Provisioning Profile from your Mac, encode them in Base64, and store them securely in **GitHub Secrets**:
- `BUILD_CERTIFICATE_BASE64`
- `P12_PASSWORD`
- `BUILD_PROVISION_PROFILE_BASE64`
- `KEYCHAIN_PASSWORD` (a temporary password you invent for the CI runner's keychain)

The workflow handles creating a temporary keychain, decoding the certificate, and applying the provisioning profile automatically.

### Step 4: Compiling with `xcodebuild`
The workflow leverages Apple's `xcodebuild` CLI tool to:
1. Resolve Swift Package Manager (SPM) dependencies.
2. Build and Archive the workspace into an `.xcarchive` file.
3. Export the archive into a distributable `.ipa` format using an auto-generated `exportOptions.plist`.

### Step 5: Artifact Collection & Distribution
- **Artifacts:** The resulting `.ipa` file is uploaded as a GitHub Artifact, making it available for you to download from the Actions tab.
- **TestFlight/App Store:** If the workflow is triggered by a GitHub Release, the workflow takes the extra step of uploading the `.ipa` directly to Apple using `xcrun altool`. You'll need to provide your `APPLE_ID` and an `APP_SPECIFIC_PASSWORD` in GitHub Secrets.

## Next Steps to Implement

To get this pipeline running in the actual Ice Cubes repository:
1. **Commit the Workflow:** Push the `.github/workflows/ios-build-distribute.yml` file to the GitHub repository.
2. **Configure GitHub Secrets:** Go to the repo settings in GitHub > **Secrets and variables** > **Actions**, and add the required Apple signing certificates and credentials.
3. **Update Team ID:** In the workflow file, update `YOUR_TEAM_ID` and `Your_Provisioning_Profile_Name` to match your Apple Developer account details.
4. **Trigger Build:** Run the workflow manually from the Actions tab to test the compilation!
