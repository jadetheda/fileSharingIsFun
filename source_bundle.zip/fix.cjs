const fs = require('fs');
const path = 'ios-workspace/IceCubesApp/App/Tabs/Timeline/TimelineTab.swift';
let lines = fs.readFileSync(path, 'utf8').split('\n');

// 1. Get the Menu code block from lines 136 to 182
// We know lines array is 0-indexed.
// line 136 is lines[135]. line 182 is lines[181].
let menuCode = lines.slice(135, 182);

// 2. We need to replace lines 253 to 295 with the menuCode.
// line 253 is lines[252]. line 295 is lines[294].
// 3. And then we need to delete lines 121 to 237 (lines[120] to lines[236]).

// Let's do it in reverse order so line numbers don't shift.
// First replace 253-295 with menuCode
lines.splice(252, 295 - 253 + 1, ...menuCode);

// Then delete 121-237
lines.splice(120, 237 - 121 + 1);

fs.writeFileSync(path, lines.join('\n'));
console.log("Done fixing timeline tab!");
