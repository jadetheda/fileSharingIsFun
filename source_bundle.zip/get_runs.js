async function main() {
  const pat = process.env.GITHUB_PAT;
  const runsResponse = await fetch('https://api.github.com/repos/jadetheda/IceCubesApp/actions/runs?per_page=5', {
    headers: { 'Authorization': `token ${pat}`, 'Accept': 'application/vnd.github.v3+json', 'User-Agent': 'AI-Studio-Agent' }
  });
  const runsData = await runsResponse.json();
  for (const run of runsData.workflow_runs) {
    console.log(`Run ${run.id}: ${run.status} - ${run.conclusion} - ${run.created_at} - ${run.head_commit.message.substring(0, 30)}`);
  }
}
main();
